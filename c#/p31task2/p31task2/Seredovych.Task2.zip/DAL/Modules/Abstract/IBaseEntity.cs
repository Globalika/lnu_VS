﻿namespace p31task2.DAL.Modules.Abstract
{
    public interface IBaseEntity
    {
        int Id { get; set; }
    }
}
