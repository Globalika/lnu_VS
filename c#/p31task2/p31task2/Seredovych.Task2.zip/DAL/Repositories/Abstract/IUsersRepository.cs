﻿using p31task2.DAL.Modules.Impl;

namespace p31task2.DAL.Repositories.Abstract
{
    public interface IUsersRepository : IRepository<User>
    {
    }
}
